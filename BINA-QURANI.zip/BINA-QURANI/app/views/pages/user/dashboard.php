<div class="container-fluid p-0">
  <div class="d-flex">
    <div id="sidebar" class="py-2" style="width:293px;background:#8FA06A;">
      <ul class="d-flex flex-column gap-2 m-0 p-0" style="list-style-type:none;">
        <li class="p-2" style="text-decoration:none;background:#7B8C56;">
          <a href="/user" class="d-flex align-items-center gap-2" style="text-decoration:none;">
            <img src="./assets/icon/dashboard-icon.png" height="20">
            <span style="font-size:20px;color:white;">Dashboard</span>
          </a>
        </li>
        <li class="p-2" style="background:#7B8C56;">
          <a href="/user" class="d-flex justify-content-between align-items-center" style="text-decoration:none;">
            <div class="d-flex align-items-center gap-2">
              <img src="./assets/icon/dashboard-icon.png" height="20">
              <span style="font-size:20px;color:white;">Master Data</span>
            </div>
            <img src="./assets/icon/dashboard-icon.png" height="20">
          </a>
        </li>

      </ul>
    </div>
    <div id="content">

    </div>
  </div>
</div>