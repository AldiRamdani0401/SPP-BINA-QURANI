<div class="container-fluid p-0" style="background:#626F47;">
  <div class="d-flex flex-column justify-content-center gap-2" style="height:100%;background:white;">
    <h1 class="bg-dark text-white p-3 align-self-center rounded-2" style="width:fit-content;"><?= $label ?></h1>
    <h4 class="text-center"><?= $message ?></h4>
  </div>
</div>