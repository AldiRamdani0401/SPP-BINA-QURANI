<?php
define(constant_name: 'DB_HOST', value: 'localhost:9090');
// define('DB_PORT', '9090');
define(constant_name: 'DB_USER', value: 'root');
define(constant_name: 'DB_PASS', value: 'root');
define(constant_name: 'DB_NAME', value: 'db_example');
